const DEFAULTS = {
  serverUrl: "",
  username: "",
  token: "",
  displayName: "",
  defaultNotebook: "Web 剪藏",
  defaultTags: "",
  imageMode: "inline",
  includeSource: true,
  outputFormat: "markdown",
  quickCapture: false,
  quickCaptureMode: "article"
};
const CONFIG_KEY = "nowenClipperConfig";
async function getConfig() {
  const store = chrome.storage.sync || chrome.storage.local;
  const data = await store.get(CONFIG_KEY);
  const raw = data[CONFIG_KEY] || {};
  return { ...DEFAULTS, ...raw };
}
async function setConfig(patch) {
  const current = await getConfig();
  const merged = { ...current, ...patch };
  const store = chrome.storage.sync || chrome.storage.local;
  await store.set({ [CONFIG_KEY]: merged });
  return merged;
}
function isConfigured(cfg) {
  return !!cfg.serverUrl && !!cfg.token;
}
function normalizeBaseUrl(url) {
  return url.trim().replace(/\/+$/, "");
}
export {
  getConfig as g,
  isConfigured as i,
  normalizeBaseUrl as n,
  setConfig as s
};
